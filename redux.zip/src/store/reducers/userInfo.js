const defalutState = {
  name: "李瑞鑫",
  age: "18",
  height: "180cm",
};
export default function userInfo(prevState = defalutState, action) {
  let { type, payload } = action;
  switch (type) {
    case "updateName":
      prevState.name = payload;
      return {
        ...prevState,
      };
    case "updateAge":
      prevState.age = payload;
      return {
        ...prevState,
      };
    case "updateHeight":
      prevState.height = payload;
      return {
        ...prevState,
      };
    default:
      return prevState;
  }
}
