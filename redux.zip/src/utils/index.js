import store from "../store/index";

import { updateActionAge } from "../store/actions/userInfoAction";

export function updateAges(value) {
  console.log("utils");
  store.dispatch(updateActionAge(value));
}
